const mongoose = require('mongoose');

const User = mongoose.model('User');

module.exports.userAdd = (req, res, next) => {
    var user = new User();
    user.firstname = req.body.firstname;
    user.lastname = req.body.lastname;
    user.email = req.body.email;
    user.address = req.body.address;
    user.save((err, doc) => {
        if (!err)
            res.send(doc);
        else {
            if (err.code == 11000)
                res.status(422).send(['Duplicate email adrress found.']);
            else
                return next(err);
        }

    });
}

module.exports.getAll = async (req, res, next) => {
    try {
        let postData = req.body;
        if (isNaN(postData.search)) {
            let getalllist = await User.find({
                "$or": [{
                    "firstname":  postData.search
                }, {
                    "lastname":postData.search
                },
                {
                    "email": postData.search
                },
                {
                    "address": postData.search
                }
                ]
            });
            return res.send(getalllist);
        } else {
            return res.json({
                    errorCode: 1, errorMessage: "Numbers cannot be searched in dictionary"
                });
        }
    } catch (error) {
        return error;
    }
    // "$or": [{
    //     "firstname": {"$like":'%'+ postData.search.toLowerCase()+'%'}
    // }, {
    //     "lastname": {"$like":'%'+postData.search.toLowerCase() +'%'}
    // },
    // {
    //     "email": {"$like":'%'+postData.search.toLowerCase()+'%'}
    // },
    // {
    //     "address": {"$like":'%'+postData.search.toLowerCase()+'%'}
    // }
    // ]
    // db.users.find({
    //     "$or": [{
    //         "email": "%%%"
    //     }]
    // });
    // allergyMastersTbl.findAll({
    //             where: {
    //                 [Op.or]: [{
    //                     firstname: postData.firstname
    //                 },
    //                 {
    //                     lastname: postData.lastname
    //                 },
    // {
    //                     email: postData.email
    //                 },
    // {
    //                     address: postData.address
    //                 }
    //                 ]
    //             }
    // if (getsearch.searchKeyWord && /\S/.test(getsearch.searchKeyWord)) {
    //     postingData.where = Object.assign(postingData.where, {
    //       [Op.and]: [{
    //         [Op.or]: [{
    //           code: {
    //             [Op.like]: '%' + getsearch.searchKeyWord.toLowerCase() + '%',
    //           }
    //         }, {
    //           name: {
    //             [Op.like]: '%' + getsearch.searchKeyWord.toLowerCase() + '%',
    //           }
    //         }]
    //       }]
    //     });
    //   }
}
